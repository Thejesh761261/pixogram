package com.pixogram.service;

import java.util.List;

import com.pixogram.model.Media;

public interface MediaService {

	public List<Media> getUsersMedia(int userId);

	public Media postMedia(Media m);
}
