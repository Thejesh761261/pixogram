package com.pixogram.service;

import java.util.List;


import com.pixogram.model.Blocked;


public interface BlockedService {
	
	public List<Blocked> getAllBlocked(); 
	
	public void unblockUser(Long id, Long blockedId);
	
	public Blocked blockUser(Blocked block);
	
}
