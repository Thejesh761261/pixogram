package com.pixogram.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pixogram.model.User;
import com.pixogram.repo.UserRepo;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	UserRepo userRepo;
	
	@Override
	public List<User> getUsers() {
		return (List<User>) userRepo.findAll();
	}

	@Override
	public User createUser(User user) {
		
		boolean active=true;
		return userRepo.save(new User(0,user.getName(), user.getEmail(), user.getPassword(),active));
	}

	@Override
	public Optional<User> getUserById(Long userId) {
		return (Optional<User>) userRepo.findById(userId);
	}

	@Override
	public List<User> searchUserByName(String value) {
		// TODO Auto-generated method stub
		return userRepo.serachUserByName(value);
	}

	@Override
	public List<User> searchNotFollowed(long id,String value) {
		// TODO Auto-generated method stub
		return userRepo.searchNotFollowed(id, value);
	}

	@Override
	public void blockUser(long uid) {
		
		userRepo.setActive(uid);
	}
	
	@Override
	public void unblockUser(long uid) {
		
		userRepo.activate(uid);
	}
}
