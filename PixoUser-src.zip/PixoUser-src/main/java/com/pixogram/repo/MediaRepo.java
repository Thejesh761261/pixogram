package com.pixogram.repo;

import org.springframework.data.repository.CrudRepository;

import com.pixogram.model.Media;

public interface MediaRepo extends CrudRepository<Media, Long> {

}
