package com.pixogram.repo;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.pixogram.model.User;

import java.util.List;

import javax.transaction.Transactional;

public interface UserRepo extends CrudRepository<User, Long>{
	
	@Query(value="Select u from User u where u.name like %?1%")
	public List<User> serachUserByName(String value);

	
	@Query(value="Select u from User u where u.id not in(Select f.followId from Follow f where f.userId like ?1 ) and u.id not in(select b.blockedId from Blocked b where b.userId like ?1) and u.name like %?2%")
	public List<User> searchNotFollowed(long id, String value);
	


	@Modifying(clearAutomatically = true)
	@Transactional
	@Query("update User r set r.active = false where r.id= :uid")
	void setActive(long uid);
	
	@Modifying(clearAutomatically = true)
	@Transactional
	@Query("update User r set r.active = true where r.id= :uid")
	void activate(long uid);
}
